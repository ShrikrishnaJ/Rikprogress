# ऋक्संहितानुष्ठानप्रगतिदर्शकः — Android project

हा Android Studio project आहे; तयार APK नाही.

## APK बनवण्याची पद्धत
1. संगणकावर Android Studio स्थापित करा.
2. Android Studio मध्ये `rigveda_android_project` फोल्डर उघडा.
3. Gradle sync पूर्ण होऊ द्या.
4. Build > Build Bundle(s) / APK(s) > Build APK(s) निवडा.
5. APK `app/build/outputs/apk/debug/app-debug.apk` येथे मिळेल.

अॅप HTML आवृत्तीला WebView मध्ये उघडते आणि WebView DOM storage वापरते. त्यामुळे अॅपमधील स्थानिक प्रगती त्याच डिव्हाइसवर साठवली जाते. हा प्रकल्प प्रत्यक्ष Android SDK/Gradle ने compile करून तपासलेला नाही.
